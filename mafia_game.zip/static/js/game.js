
function startGame() {
    const gameArea = document.getElementById('game-area');
    gameArea.innerHTML = "<p>بازی آغاز شد! بازیکنان نقش‌ها را دریافت می‌کنند...</p>";
}
